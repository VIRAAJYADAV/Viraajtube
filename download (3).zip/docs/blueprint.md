# **App Name**: CoinTube

## Core Features:

- User Authentication: Users can log in, view their coin balance, and log out.
- Channel List: Displays a list of YouTube channels for the user to subscribe to.
- Subscription Tracking: Tracks which channels the user has subscribed to. Once a user has subscribed, allow them to collect coins
- Coin Balance: Displays the number of coins a user has. 50,000 Coins = ₹25.
- Withdrawal System: Displays a withdrawal interface. Users can input their name, phone number, UPI ID, and the number of coins to withdraw. After a withdrawal request is sent, an alert confirms the request.
- Informative Messages: Displays a curated set of success and error messages at the right moments to confirm to the user the consequence of their actions. An alert box can be reused here. All information the user needs should come directly from the HTML, not generated via AI tool calls.

## Style Guidelines:

- Primary color: Saturated red (#D62828) for high-energy calls to action
- Background color: Desaturated, dark red (#260707) for a high-contrast dark scheme
- Accent color: Analogous orange (#F77F00), much brighter and more saturated than the others, for visual interest
- Body and headline font: 'Space Grotesk' (sans-serif) for a tech-friendly look
- Use Font Awesome icons to represent actions, categories and concepts
- The application should reflow to be mobile-responsive on smaller screens
- Subtle animations on button clicks, coin updates, and notifications to create a dynamic and engaging user experience.