export interface Subscription {
  id: string;
  name: string;
  url: string;
  subscribedAt: string; // ISO string
}

export interface Channel {
  id: string;
  name: string;
  url: string;
  cost: number;
  addedAt: string; // ISO string
}

export interface UserData {
  coins: number;
  subscriptions: Subscription[];
  channels: Channel[];
  collectedChannels: string[]; // Array of channel IDs that have been collected from
}

export interface WithdrawalRequest {
  name: string;
  phone: string;
  upi: string;
  coins: number;
  amount: number;
  requestedAt: string;
}
