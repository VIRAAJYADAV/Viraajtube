"use client";

import { Users, MessageSquare, UserCheck } from "lucide-react";
import { Button } from "./ui/button";
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

const mockSubscribers = [
  { id: 1, name: "Subscriber One", avatar: "https://placehold.co/40x40.png", subscribedAt: "2024-07-20T10:00:00Z" },
  { id: 2, name: "Subscriber Two", avatar: "https://placehold.co/40x40.png", subscribedAt: "2024-07-19T11:30:00Z" },
  { id: 3, name: "Subscriber Three", avatar: "https://placehold.co/40x40.png", subscribedAt: "2024-07-18T15:45:00Z" },
  { id: 4, name: "Subscriber Four", avatar: "https://placehold.co/40x40.png", subscribedAt: "2024-07-17T09:00:00Z" },
];

export default function MySubscribersTab() {
  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 slide-in">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
          <Users className="mr-2" /> My Subscribers
      </h2>
      <div className="space-y-4">
        {mockSubscribers.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            <UserCheck className="h-10 w-10 mx-auto mb-4" />
            <p>You don't have any subscribers yet.</p>
            <p className="text-sm mt-2">Add your channel and share it to get subscribers!</p>
          </div>
        ) : (
          <>
            {mockSubscribers.map((sub) => (
              <div key={sub.id} className="bg-gray-800 p-4 rounded-xl">
                <div className="flex flex-wrap justify-between items-center gap-4">
                  <div className="flex items-center gap-4">
                     <Avatar>
                        <AvatarImage src={sub.avatar} alt={sub.name} />
                        <AvatarFallback>{sub.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <h3 className="text-lg font-semibold flex items-center">
                            {sub.name}
                        </h3>
                        <p className="text-gray-400 text-sm">
                            Subscribed on: {new Date(sub.subscribedAt).toLocaleDateString()}
                        </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button asChild size="sm" className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg">
                      <Link href="https://t.me/dreamDripLofi1" target="_blank">
                        <MessageSquare className="mr-2 h-4 w-4" /> Chat
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
