import { ShieldCheck, Clock, Landmark } from "lucide-react";

export default function AppFooter() {
  return (
    <footer className="bg-black/70 backdrop-blur-sm mt-12 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center flex flex-col items-center">
            <ShieldCheck className="h-8 w-8 text-green-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Trusted Platform</h3>
            <p className="text-gray-400">100% Safe & Secure</p>
          </div>
          <div className="text-center flex flex-col items-center">
            <Clock className="h-8 w-8 text-blue-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">24/7 Support</h3>
            <p className="text-gray-400">Round the clock assistance</p>
          </div>
          <div className="text-center flex flex-col items-center">
            <Landmark className="h-8 w-8 text-yellow-500 mb-4" />
            <h3 className="text-lg font-semibold mb-2">Instant Payments</h3>
            <p className="text-gray-400">Quick withdrawal process</p>
          </div>
        </div>
        <div className="text-center mt-8 pt-8 border-t border-gray-700">
          <p className="text-gray-400">&copy; 2024 VIRAAJTube. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
