"use client";

import { useState } from "react";
import { Flame, LogIn, UserPlus, Eye, EyeOff } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface LoginFormProps {
  onLoginSuccess: () => void;
}

export default function LoginForm({ onLoginSuccess }: LoginFormProps) {
  const { toast } = useToast();
  const [isSignUp, setIsSignUp] = useState(false);
  
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const storedUsers = JSON.parse(localStorage.getItem("VIRAAJTubeUsers") || "{}");
    const validCredentials: Record<string, string> = {
      user: "pass",
      admin: "admin123",
      demo: "demo",
      ...storedUsers
    };
    
    if (validCredentials[username] === password) {
      onLoginSuccess();
    } else {
      toast({
        title: "Invalid Credentials",
        description: "Please check your username and password.",
        variant: "destructive"
      });
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({
        title: "Passwords do not match",
        variant: "destructive"
      });
      return;
    }
    if (newPassword.length < 6) {
        toast({
            title: "Password too short",
            description: "Password must be at least 6 characters.",
            variant: "destructive"
        });
        return;
    }

    const storedUsers = JSON.parse(localStorage.getItem("VIRAAJTubeUsers") || "{}");
    if (storedUsers[email]) {
        toast({
            title: "User already exists",
            description: "An account with this email already exists. Please log in.",
            variant: "destructive"
        });
        return;
    }

    const newUsers = { ...storedUsers, [email]: newPassword };
    localStorage.setItem("VIRAAJTubeUsers", JSON.stringify(newUsers));
    
    // Also store user details for potential future use
    const userDetails = { name, email };
    localStorage.setItem(`VIRAAJTubeUser_${email}`, JSON.stringify(userDetails));

    toast({
        title: "Sign Up Successful!",
        description: "You can now log in with your new account.",
        className: "bg-green-500 text-white"
    });
    
    // Automatically log in the user after successful sign-up
    onLoginSuccess();
  };

  const toggleForm = () => {
    setIsSignUp(!isSignUp);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-black/60 backdrop-blur-sm p-8 rounded-3xl slide-in">
        <div className="text-center mb-8">
            <div className="floating inline-block">
              <Flame className="h-16 w-16 text-red-500 mb-4" />
            </div>
          <h1 className="text-4xl font-bold mb-2">VIRAAJTube</h1>
          <p className="text-gray-300">Premium Subscription Platform</p>
        </div>
        
        {isSignUp ? (
          <form onSubmit={handleSignUp} className="space-y-6">
            <h2 className="text-2xl font-bold text-center">Create Account</h2>
            <Input type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition" />
            <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition" />
            <div className="relative">
                <Input type={showNewPassword ? "text" : "password"} placeholder="Password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition pr-10" />
                <Button type="button" variant="ghost" size="icon" className="absolute inset-y-0 right-0 text-gray-400 hover:text-white" onClick={() => setShowNewPassword(!showNewPassword)}>
                    {showNewPassword ? <EyeOff /> : <Eye />}
                </Button>
            </div>
            <div className="relative">
                <Input type={showConfirmPassword ? "text" : "password"} placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition pr-10" />
                 <Button type="button" variant="ghost" size="icon" className="absolute inset-y-0 right-0 text-gray-400 hover:text-white" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>
                    {showConfirmPassword ? <EyeOff /> : <Eye />}
                </Button>
            </div>
            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 rounded-xl py-3 font-semibold transition pulse-button h-auto text-base">
              <UserPlus className="mr-2 h-5 w-5" /> Sign Up
            </Button>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-6">
            <h2 className="text-2xl font-bold text-center">Login</h2>
            <Input type="text" placeholder="Username or Email" value={username} onChange={(e) => setUsername(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition" />
            <div className="relative">
                <Input type={showNewPassword ? "text" : "password"} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500 transition pr-10" />
                <Button type="button" variant="ghost" size="icon" className="absolute inset-y-0 right-0 text-gray-400 hover:text-white" onClick={() => setShowNewPassword(!showNewPassword)}>
                        {showNewPassword ? <EyeOff /> : <Eye />}
                </Button>
            </div>
            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 rounded-xl py-3 font-semibold transition pulse-button h-auto text-base">
              <LogIn className="mr-2 h-5 w-5" /> Login
            </Button>
          </form>
        )}

        <div className="mt-6 text-center text-sm text-gray-400">
          <Button variant="link" onClick={toggleForm} className="text-gray-300 hover:text-white">
            {isSignUp ? "Already have an account? Login" : "Don't have an account? Sign Up"}
          </Button>
        </div>
      </div>
    </div>
  );
}
