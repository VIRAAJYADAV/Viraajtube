"use client";

import { Trophy, User, Medal } from "lucide-react";

const mockLeaderboardData = [
  { name: "User_Alpha", subscriptions: 25, rank: 1, avatar: "https://placehold.co/40x40.png" },
  { name: "User_Beta", subscriptions: 22, rank: 2, avatar: "https://placehold.co/40x40.png" },
  { name: "User_Gamma", subscriptions: 18, rank: 3, avatar: "https://placehold.co/40x40.png" },
  { name: "User_Delta", subscriptions: 15, rank: 4, avatar: "https://placehold.co/40x40.png" },
  { name: "User_Epsilon", subscriptions: 12, rank: 5, avatar: "https://placehold.co/40x40.png" },
];

const getMedalColor = (rank: number) => {
    switch (rank) {
      case 1: return "text-yellow-400";
      case 2: return "text-gray-400";
      case 3: return "text-yellow-600";
      default: return "text-gray-500";
    }
}

export default function LeaderboardTab() {
  const topThree = mockLeaderboardData.slice(0, 3);
  const others = mockLeaderboardData.slice(3);

  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 slide-in">
      <h2 className="text-3xl font-bold mb-6 flex items-center justify-center text-center">
        <Trophy className="mr-3 text-yellow-400" size={32} /> Subscription Leaderboard
      </h2>

      <div className="space-y-8">
        {/* Top 3 Podium */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {topThree.map((user, index) => (
            <div 
              key={user.rank} 
              className={`bg-gray-800 p-6 rounded-2xl border-2 ${index === 0 ? "border-yellow-400" : (index === 1 ? "border-gray-400" : "border-yellow-600")} shadow-lg flex flex-col items-center ${index === 0 ? "md:scale-110" : ""}`}
            >
              <Medal className={`${getMedalColor(user.rank)} mb-3`} size={40} />
              <img src={user.avatar} alt={user.name} className="w-20 h-20 rounded-full mb-4 border-4 border-gray-700"/>
              <h3 className="text-xl font-bold">{user.name}</h3>
              <p className="text-lg text-gray-300">{user.subscriptions} Subscriptions</p>
            </div>
          ))}
        </div>

        {/* Other Ranks */}
        {others.length > 0 && (
            <div>
                 <h3 className="text-xl font-bold mt-12 mb-4 text-center">Top Ranks</h3>
                 <div className="space-y-3">
                    {others.map((user) => (
                        <div key={user.rank} className="bg-gray-800 p-4 rounded-xl flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <span className="font-bold text-lg w-6 text-center">{user.rank}</span>
                                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full"/>
                                <span className="font-semibold">{user.name}</span>
                            </div>
                            <span className="font-semibold text-gray-300">{user.subscriptions} Subscriptions</span>
                        </div>
                    ))}
                 </div>
            </div>
        )}
      </div>
    </div>
  );
}
