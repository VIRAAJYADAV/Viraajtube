"use client";

import type { UserData } from "@/lib/types";
import { Button } from "./ui/button";
import { Crown, Youtube, Coins, MessageSquare, Send, Share2 } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import LeaderboardTab from "./leaderboard-tab";
import { useToast } from "@/hooks/use-toast";

interface HomeTabProps {
  userData: UserData;
  onSubscribe: (id: string, name: string, url: string) => void;
  onCollect: (id: string, amount: number) => void;
  onShare: () => void;
}

export default function HomeTab({ userData, onSubscribe, onCollect, onShare }: HomeTabProps) {
  const { toast } = useToast();
  const ownerChannel = {
    id: "owner",
    name: "Dream Drip Lofi Channel",
    url: "https://youtube.com/@dreamdriplofi-p5h?si=di_twPPq7bPDuM6x",
    reward: 100,
  };

  const isSubscribed = userData.subscriptions.some(sub => sub.id === ownerChannel.id);
  const hasCollected = userData.collectedChannels.includes(ownerChannel.id);
  const [showCollect, setShowCollect] = useState(false);

  useEffect(() => {
    if (isSubscribed) {
        const timer = setTimeout(() => setShowCollect(true), 2000);
        return () => clearTimeout(timer);
    }
  }, [isSubscribed]);

  const handleSubscribe = () => {
    onSubscribe(ownerChannel.id, ownerChannel.name, ownerChannel.url);
  };
  
  const handleShare = async () => {
    const shareData = {
      title: 'VIRAAJTube',
      text: 'Check out VIRAAJTube - A premium subscription platform!',
      url: window.location.href
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        onShare();
      } else {
        // Fallback for browsers that don't support navigator.share
        navigator.clipboard.writeText(shareData.url);
        toast({
          title: "Link Copied!",
          description: "The referral link has been copied to your clipboard.",
        });
        onShare();
      }
    } catch (error) {
      console.error('Error sharing:', error);
      toast({
        title: "Sharing Failed",
        description: "Could not share at this moment. Please try again later.",
        variant: "destructive"
      })
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 mb-6 slide-in">
          <div className="text-center mb-6">
              <Crown className="w-10 h-10 text-yellow-500 mb-4 mx-auto" />
              <h2 className="text-2xl font-bold mb-2">👑 Owner Channel - पहले Subscribe करें!</h2>
              <div className="bg-red-800 rounded-xl p-4">
                  <h3 className="text-xl font-semibold mb-4 flex items-center justify-center">
                      <Youtube className="mr-2" />
                      {ownerChannel.name}
                  </h3>
                  <div className="flex flex-wrap gap-4 justify-center">
                    <Button asChild className="bg-red-600 hover:bg-red-700 px-6 py-3 text-base font-semibold transition pulse-button" onClick={handleSubscribe}>
                      <Link href={ownerChannel.url} target="_blank">
                        <Youtube className="mr-2" />
                        Subscribe Now
                      </Link>
                    </Button>
                    {isSubscribed && showCollect && (
                        <Button 
                            id="collectOwnerCoins"
                            onClick={() => onCollect(ownerChannel.id, ownerChannel.reward)}
                            disabled={hasCollected}
                            className="ml-4 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:opacity-70 px-6 py-3 text-base font-semibold transition">
                            <Coins className="mr-2" />
                            {hasCollected ? 'Collected' : `Collect ${ownerChannel.reward} Coins`}
                        </Button>
                    )}
                  </div>
              </div>
          </div>
      </div>
      
      <LeaderboardTab />

       <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 mb-6 slide-in">
        <h2 className="text-xl font-bold mb-4 flex items-center">
            <Share2 className="mr-2" />
            Share and Earn
        </h2>
        <p className="text-gray-300 mb-4">Share the app with your friends and earn 100 coins instantly!</p>
        <Button onClick={handleShare} className="bg-purple-600 hover:bg-purple-700 font-semibold transition px-6 py-3">
            <Share2 className="mr-2" />
            Share Now & Earn 100 Coins
        </Button>
      </div>

      <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 mb-6 slide-in">
        <h2 className="text-xl font-bold mb-4 flex items-center">
            <MessageSquare className="mr-2" />
            Chat with Owner
        </h2>
        <Button asChild className="bg-blue-600 hover:bg-blue-700 font-semibold transition px-6 py-3">
            <Link href="https://t.me/dreamDripLofi1" target="_blank">
                <Send className="mr-2" />
                Telegram पर चैट करें
            </Link>
        </Button>
      </div>
    </div>
  );
}
