"use client";

import type { UserData } from "@/lib/types";
import { Button } from "./ui/button";
import { List, Youtube, ExternalLink, Tv, MessageSquare } from "lucide-react";
import Link from "next/link";

interface SubscriptionsTabProps {
  userData: UserData;
}

export default function SubscriptionsTab({ userData }: SubscriptionsTabProps) {
  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 slide-in">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
          <List className="mr-2" /> My Subscriptions
      </h2>
      <div className="space-y-4">
        {userData.subscriptions.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            <Tv className="h-10 w-10 mx-auto mb-4" />
            <p>No subscriptions yet. Start subscribing to channels!</p>
          </div>
        ) : (
          <>
            {userData.subscriptions.map((sub) => (
              <div key={sub.id} className="bg-gray-800 p-4 rounded-xl">
                <div className="flex flex-wrap justify-between items-center gap-4">
                  <div>
                    <h3 className="text-lg font-semibold flex items-center">
                      <Youtube className="mr-2 text-red-500" />
                      {sub.name}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      Subscribed: {new Date(sub.subscribedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button asChild size="sm" className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg">
                      <Link href="https://t.me/dreamDripLofi1" target="_blank">
                        <MessageSquare className="mr-2 h-4 w-4" /> Chat
                      </Link>
                    </Button>
                    <Button asChild size="sm" className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg">
                      <Link href={sub.url} target="_blank">
                        <ExternalLink className="mr-2 h-4 w-4" /> Visit
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
