"use client";

import type { Channel, UserData } from "@/lib/types";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Plus, Youtube, Coins, Tv } from "lucide-react";
import Link from "next/link";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "./ui/form";
import { useEffect, useState } from "react";

const addChannelSchema = z.object({
  channelName: z.string().min(3, "Channel name must be at least 3 characters"),
  channelUrl: z.string().url("Please enter a valid YouTube channel URL"),
});
type AddChannelFormValues = z.infer<typeof addChannelSchema>;

interface ChannelsTabProps {
  userData: UserData;
  onSubscribe: (id: string, name: string, url: string) => void;
  onCollect: (id: string, amount: number) => void;
  onAddChannel: (name: string, url: string) => void;
}

interface ChannelItemProps {
  channel: Channel;
  isSubscribed: boolean;
  hasCollected: boolean;
  onSubscribe: (id: string, name: string, url: string) => void;
  onCollect: (id: string, amount: number) => void;
}

const ChannelItem = ({ channel, isSubscribed, hasCollected, onSubscribe, onCollect }: ChannelItemProps) => {
    const [showCollect, setShowCollect] = useState(false);

    useEffect(() => {
        if (isSubscribed) {
            const timer = setTimeout(() => setShowCollect(true), 2000);
            return () => clearTimeout(timer);
        }
    }, [isSubscribed]);

    const handleSubscribe = () => {
        onSubscribe(channel.id, channel.name, channel.url);
    }
    
    return (
        <div data-channel={channel.id} className="bg-gray-800 p-4 rounded-xl">
            <h3 className="text-lg font-semibold mb-2 flex items-center">
                <Youtube className="mr-2 text-red-500" />
                {channel.name}
            </h3>
            <div className="flex space-x-3">
                <Button asChild size="sm" className="bg-red-600 hover:bg-red-700" onClick={handleSubscribe}>
                    <Link href={channel.url} target="_blank">
                        <Youtube className="mr-2" /> Subscribe
                    </Link>
                </Button>
                {isSubscribed && showCollect && (
                     <Button 
                        size="sm"
                        onClick={() => onCollect(channel.id, channel.cost)}
                        disabled={hasCollected}
                        className="collect-btn bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:opacity-70">
                        <Coins className="mr-2" />
                        {hasCollected ? 'Collected' : `Collect ${channel.cost} Coins`}
                    </Button>
                )}
            </div>
        </div>
    );
}

export default function ChannelsTab({ userData, onSubscribe, onCollect, onAddChannel }: ChannelsTabProps) {
  const form = useForm<AddChannelFormValues>({
    resolver: zodResolver(addChannelSchema),
    defaultValues: { channelName: "", channelUrl: "" },
  });

  const onSubmit: SubmitHandler<AddChannelFormValues> = (data) => {
    onAddChannel(data.channelName, data.channelUrl);
    form.reset();
  };

  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 slide-in">
      <h2 className="text-2xl font-bold mb-6 flex items-center">
        <Tv className="mr-2" /> Other Channels
      </h2>

      <div className="mb-8 p-4 bg-gray-800 rounded-xl">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Plus className="mr-2" /> Add Your Channel
        </h3>
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="channelName"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="Channel Name" {...field} className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="channelUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input placeholder="YouTube Channel URL" {...field} className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-red-500"/>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="bg-green-600 hover:bg-green-700 px-6 py-3 rounded-lg font-semibold transition">
                <Plus className="mr-2" /> Add Channel
              </Button>
            </form>
          </Form>
      </div>

      <div id="channelsList" className="grid gap-4">
        {userData.channels.map((channel) => (
          <ChannelItem 
            key={channel.id}
            channel={channel}
            isSubscribed={userData.subscriptions.some(sub => sub.id === channel.id)}
            hasCollected={userData.collectedChannels.includes(channel.id)}
            onSubscribe={onSubscribe}
            onCollect={onCollect}
          />
        ))}
      </div>
    </div>
  );
}
