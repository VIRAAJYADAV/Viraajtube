"use client";

import { useUserData } from "@/hooks/use-user-data";
import AppHeader from "./app-header";
import AppFooter from "./app-footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Home, List, Tv, Wallet, Users } from "lucide-react";
import HomeTab from "./home-tab";
import ChannelsTab from "./channels-tab";
import SubscriptionsTab from "./subscriptions-tab";
import WithdrawTab from "./withdraw-tab";
import MySubscribersTab from "./my-subscribers-tab";

interface DashboardProps {
  onLogout: () => void;
}

export default function Dashboard({ onLogout }: DashboardProps) {
  const { userData, addSubscription, collectCoins, addChannel, requestWithdrawal, addCoins } = useUserData();

  if (!userData) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  const handleShare = () => {
      addCoins(100, "for sharing the app");
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader
        coinCount={userData.coins}
        onLogout={onLogout}
      />
      <main className="flex-grow">
        <Tabs defaultValue="home" className="w-full">
          <nav className="bg-black/30 backdrop-blur-sm p-4">
              <TabsList className="flex space-x-2 overflow-x-auto max-w-6xl mx-auto h-auto bg-transparent p-0">
                <TabsTrigger value="home" className="nav-btn active bg-red-600 px-4 py-2 rounded-lg whitespace-nowrap data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=inactive]:bg-gray-700 data-[state=inactive]:hover:bg-gray-600"><Home className="mr-2" />Home</TabsTrigger>
                <TabsTrigger value="channels" className="nav-btn bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg whitespace-nowrap data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=inactive]:bg-gray-700 data-[state=inactive]:hover:bg-gray-600"><Tv className="mr-2" />Channels</TabsTrigger>
                <TabsTrigger value="subscriptions" className="nav-btn bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg whitespace-nowrap data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=inactive]:bg-gray-700 data-[state=inactive]:hover:bg-gray-600"><List className="mr-2" />My Subscriptions</TabsTrigger>
                <TabsTrigger value="my-subscribers" className="nav-btn bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg whitespace-nowrap data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=inactive]:bg-gray-700 data-[state=inactive]:hover:bg-gray-600"><Users className="mr-2" />My Subscribers</TabsTrigger>
                <TabsTrigger value="withdraw" className="nav-btn bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg whitespace-nowrap data-[state=active]:bg-red-600 data-[state=active]:text-white data-[state=inactive]:bg-gray-700 data-[state=inactive]:hover:bg-gray-600"><Wallet className="mr-2" />Withdraw</TabsTrigger>
              </TabsList>
          </nav>
          <div className="p-4 max-w-6xl mx-auto">
            <TabsContent value="home" className="tab-content mt-0">
              <HomeTab userData={userData} onSubscribe={addSubscription} onCollect={collectCoins} onShare={handleShare} />
            </TabsContent>
            <TabsContent value="channels" className="tab-content mt-0">
              <ChannelsTab userData={userData} onSubscribe={addSubscription} onCollect={collectCoins} onAddChannel={addChannel} />
            </TabsContent>
            <TabsContent value="subscriptions" className="tab-content mt-0">
              <SubscriptionsTab userData={userData} />
            </TabsContent>
            <TabsContent value="my-subscribers" className="tab-content mt-0">
                <MySubscribersTab />
            </TabsContent>
            <TabsContent value="withdraw" className="tab-content mt-0">
              <WithdrawTab userData={userData} onWithdraw={requestWithdrawal} />
            </TabsContent>
          </div>
        </Tabs>
      </main>
      <AppFooter />
    </div>
  );
}
