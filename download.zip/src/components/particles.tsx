"use client";

import { useEffect, useMemo } from 'react';

const Particle = ({ style }: { style: React.CSSProperties }) => <div className="absolute rounded-full bg-white/10" style={style} />;

export default function Particles() {
  const particles = useMemo(() => {
    return Array.from({ length: 50 }).map((_, i) => ({
      id: i,
      style: {
        left: `${Math.random() * 100}%`,
        animation: `particleFloat ${Math.random() * 10 + 10}s infinite linear`,
        animationDelay: `${Math.random() * 20}s`,
        width: `${Math.random() * 4 + 2}px`,
        height: `${Math.random() * 4 + 2}px`,
      },
    }));
  }, []);

  useEffect(() => {
    const styleSheet = document.createElement("style");
    styleSheet.innerHTML = `
      @keyframes particleFloat {
        0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
      }
    `;
    document.head.appendChild(styleSheet);
    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);
  
  return (
    <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
      {particles.map(p => (
        <Particle key={p.id} style={p.style} />
      ))}
    </div>
  );
}
