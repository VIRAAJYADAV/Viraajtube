"use client";

import type { UserData } from "@/lib/types";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Wallet, Info, Send } from "lucide-react";
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "./ui/form";
import { useState } from "react";

const WITHDRAWAL_RATE = 25 / 50000; // 25 rupees for 50000 coins
const MIN_WITHDRAWAL = 50000;

const withdrawSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().regex(/^\d{10}$/, "Please enter a valid 10-digit phone number"),
  upi: z.string().min(3, "UPI ID is required"),
  coins: z.coerce.number().min(MIN_WITHDRAWAL, `Minimum withdrawal is ${MIN_WITHDRAWAL.toLocaleString()} coins`),
});
type WithdrawFormValues = z.infer<typeof withdrawSchema>;

interface WithdrawTabProps {
  userData: UserData;
  onWithdraw: (coins: number, name: string, phone: string, upi: string) => boolean;
}

export default function WithdrawTab({ userData, onWithdraw }: WithdrawTabProps) {
  const [withdrawAmount, setWithdrawAmount] = useState(0);

  const form = useForm<WithdrawFormValues>({
    resolver: zodResolver(withdrawSchema),
    defaultValues: { name: "", phone: "", upi: "", coins: MIN_WITHDRAWAL },
  });

  const onSubmit: SubmitHandler<WithdrawFormValues> = (data) => {
    const success = onWithdraw(data.coins, data.name, data.phone, data.upi);
    if(success) {
        form.reset();
        setWithdrawAmount(0);
    }
  };

  const handleCoinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const coins = parseInt(e.target.value) || 0;
    setWithdrawAmount(coins * WITHDRAWAL_RATE);
    form.setValue("coins", coins, { shouldValidate: true });
  }

  return (
    <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 slide-in">
        <h2 className="text-2xl font-bold mb-6 flex items-center">
            <Wallet className="mr-2" /> Withdraw Coins
        </h2>
        
        <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-black p-4 rounded-xl mb-6">
          <h3 className="text-lg font-bold mb-2 flex items-center">
            <Info className="mr-2" /> Conversion Rate
          </h3>
          <p className="text-xl font-semibold">{MIN_WITHDRAWAL.toLocaleString()} Coins = ₹{MIN_WITHDRAWAL * WITHDRAWAL_RATE}</p>
          <p>Minimum withdrawal: {MIN_WITHDRAWAL.toLocaleString()} coins</p>
        </div>
        
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem><FormLabel className="block text-sm font-semibold mb-2">Name</FormLabel><FormControl><Input className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                 <FormField control={form.control} name="phone" render={({ field }) => (
                    <FormItem><FormLabel className="block text-sm font-semibold mb-2">Phone Number</FormLabel><FormControl><Input type="tel" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                 <FormField control={form.control} name="upi" render={({ field }) => (
                    <FormItem><FormLabel className="block text-sm font-semibold mb-2">UPI ID</FormLabel><FormControl><Input className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                 <FormField control={form.control} name="coins" render={({ field }) => (
                    <FormItem>
                        <FormLabel className="block text-sm font-semibold mb-2">Coins to Withdraw (Your balance: {userData.coins.toLocaleString()})</FormLabel>
                        <FormControl><Input type="number" step="1000" min="50000" className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500" {...field} onChange={handleCoinChange} /></FormControl>
                        <FormMessage />
                        <p className="text-sm text-gray-400 mt-1">Amount: ₹<span id="withdrawAmount">{withdrawAmount.toFixed(2)}</span></p>
                    </FormItem>
                )} />
                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700 py-3 rounded-lg font-semibold transition pulse-button h-auto text-base">
                    <Send className="mr-2" /> Request Withdrawal
                </Button>
            </form>
        </Form>
    </div>
  );
}
