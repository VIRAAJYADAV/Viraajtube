"use client";

import { Button } from "./ui/button";
import { Coins, Flame, LogOut } from "lucide-react";

interface AppHeaderProps {
  coinCount: number;
  onLogout: () => void;
}

export default function AppHeader({ coinCount, onLogout }: AppHeaderProps) {
  return (
    <header className="bg-black/50 backdrop-blur-sm p-4">
      <div className="flex justify-between items-center max-w-6xl mx-auto">
        <div className="flex items-center space-x-4">
          <Flame className="h-7 w-7 text-red-500 floating" />
          <h1 className="text-2xl font-bold">VIRAAJTube</h1>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-yellow-500 text-black px-4 py-2 rounded-full font-semibold flex items-center coin-animation">
            <Coins className="mr-2 h-5 w-5" />
            <span>{coinCount.toLocaleString()}</span>
            <span className="ml-1">Coins</span>
          </div>
          <Button onClick={onLogout} variant="destructive" size="sm" className="bg-red-600 hover:bg-red-700">
            <LogOut className="mr-2 h-4 w-4" /> Logout
          </Button>
        </div>
      </div>
    </header>
  );
}
