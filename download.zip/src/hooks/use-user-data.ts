"use client";

import { useState, useEffect, useCallback } from "react";
import type { UserData, Subscription, Channel } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

const MIN_WITHDRAWAL = 50000;
const WITHDRAWAL_RATE = 25 / 50000;

const INITIAL_CHANNELS: Channel[] = [
  {
    id: "tech-abc",
    name: "Tech With ABC",
    url: "https://youtube.com",
    cost: 50,
    addedAt: new Date().toISOString(),
  },
];

const getInitialData = (): UserData => {
  if (typeof window === 'undefined') {
    return {
      coins: 0,
      subscriptions: [],
      channels: INITIAL_CHANNELS,
      collectedChannels: [],
    };
  }
  try {
    const storedData = localStorage.getItem("VIRAAJTubeData");
    if (storedData) {
      const parsed = JSON.parse(storedData);
      // Basic validation to ensure data structure is not completely broken
      if (typeof parsed.coins === 'number' && Array.isArray(parsed.subscriptions)) {
        // Ensure channels and collectedToday are initialized if not present
        if (!parsed.channels) {
          parsed.channels = INITIAL_CHANNELS;
        }
        if (!parsed.collectedChannels) {
            parsed.collectedChannels = [];
        }
        // This is to migrate from old "collectedToday" to new "collectedChannels"
        if (parsed.collectedToday) {
            delete parsed.collectedToday;
        }
        return parsed;
      }
    }
  } catch (error) {
    console.error("Failed to parse user data from localStorage", error);
  }
  // Return default state if anything goes wrong
  return {
    coins: 0,
    subscriptions: [],
    channels: INITIAL_CHANNELS,
    collectedChannels: [],
  };
};

export function useUserData() {
  const { toast } = useToast();
  const [userData, setUserData] = useState<UserData | null>(null);

  useEffect(() => {
    setUserData(getInitialData());
  }, []);

  const saveData = useCallback((newData: UserData) => {
    try {
      localStorage.setItem("VIRAAJTubeData", JSON.stringify(newData));
      setUserData(newData);
    } catch (error) {
      console.error("Failed to save user data", error);
    }
  }, []);

  const addCoins = useCallback((amount: number, reason: string) => {
    if (!userData) return;

    const newData = {
        ...userData,
        coins: userData.coins + amount
    };
    saveData(newData);
    toast({
      title: "Coins Added!",
      description: `You earned ${amount} coins ${reason}.`,
      className: "bg-green-500 text-white"
    });

  }, [userData, saveData, toast]);


  const addSubscription = useCallback((channelId: string, channelName: string, channelUrl: string) => {
      if (!userData) return;
      if (userData.subscriptions.some((sub) => sub.id === channelId)) {
        toast({
            title: "Already Subscribed",
            description: "You are already subscribed to this channel.",
            variant: "destructive",
        });
        return;
      }

      const newSubscription: Subscription = {
        id: channelId,
        name: channelName,
        url: channelUrl,
        subscribedAt: new Date().toISOString(),
      };

      const newData = {
        ...userData,
        subscriptions: [...userData.subscriptions, newSubscription],
      };
      saveData(newData);
      
    }, [userData, saveData, toast]
  );
  
  const collectCoins = useCallback((channelId: string, amount: number) => {
      if (!userData) return;
      
      if (userData.collectedChannels.includes(channelId)) {
        toast({
            title: "Already Collected",
            description: "You have already collected coins for this subscription.",
            variant: "destructive",
        });
        return;
      }
      
      if (!userData.subscriptions.find((sub) => sub.id === channelId)) {
        toast({
            title: "Subscription Required",
            description: "Please subscribe to this channel first to collect coins.",
            variant: "destructive",
        });
        return;
      }

      const newData = {
          ...userData,
          coins: userData.coins + amount,
          collectedChannels: [...userData.collectedChannels, channelId]
      }
      saveData(newData);

      toast({
        title: "Coins Collected!",
        description: `+${amount} Coins Earned for subscribing!`,
        className: "bg-yellow-500 text-black",
      });

  }, [userData, saveData, toast]);

  const addChannel = useCallback((name: string, url: string) => {
    if (!userData) return;

    if (userData.channels.some(channel => channel.url.toLowerCase() === url.toLowerCase())) {
        toast({
            title: "Channel Exists",
            description: "This channel has already been added.",
            variant: "destructive",
        });
        return;
    }

    const newChannel: Channel = {
      id: `custom_${Date.now()}`,
      name,
      url,
      cost: 50, // Default cost for new channels
      addedAt: new Date().toISOString(),
    };

    const newData = {
      ...userData,
      channels: [newChannel, ...userData.channels],
    };
    saveData(newData);
    toast({
        title: "Channel Added",
        description: "Your channel has been added successfully!",
        className: "bg-green-500 text-white"
    });
  }, [userData, saveData, toast]);

  const requestWithdrawal = useCallback((coins: number, name: string, phone: string, upi: string) => {
      if(!userData) return false;
      
      if(coins > userData.coins) {
        toast({
            title: "Insufficient Coins",
            description: `You have only ${userData.coins.toLocaleString()} coins.`,
            variant: "destructive",
        });
        return false;
      }

      if (coins < MIN_WITHDRAWAL) {
        toast({
            title: "Minimum Withdrawal",
            description: `The minimum withdrawal amount is ${MIN_WITHDRAWAL.toLocaleString()} coins.`,
            variant: "destructive",
        });
        return false;
      }

      const newData = { ...userData, coins: userData.coins - coins };
      saveData(newData);
      
      const amount = coins * WITHDRAWAL_RATE;
      const message = `Withdrawal Request:\nName: ${name}\nPhone: ${phone}\nUPI: ${upi}\nCoins: ${coins.toLocaleString()}\nAmount: ₹${amount.toFixed(2)}`;
      
      toast({
          title: "Request Sent!",
          description: "Your withdrawal request has been sent to the owner.",
          className: "bg-blue-500 text-white"
      });

      console.info(message);
      
      return true;

  }, [userData, saveData, toast]);

  return { userData, addSubscription, collectCoins, addChannel, requestWithdrawal, addCoins };
}
