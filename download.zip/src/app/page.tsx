"use client";

import { useState, useEffect } from "react";
import LoginForm from "@/components/login-form";
import Dashboard from "@/components/dashboard";
import Particles from "@/components/particles";

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Using a timeout to prevent flash of unauthenticated content,
    // and to ensure localStorage is available on the client.
    const timer = setTimeout(() => {
      const sessionState = localStorage.getItem("VIRAAJTubeAuthenticated");
      if (sessionState === "true") {
        setIsAuthenticated(true);
      }
      setIsLoading(false);
    }, 100); // A small delay can help client-side checks
    
    return () => clearTimeout(timer);
  }, []);

  const handleLoginSuccess = () => {
    localStorage.setItem("VIRAAJTubeAuthenticated", "true");
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("VIRAAJTubeAuthenticated");
    setIsAuthenticated(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full gradient-bg">
      <Particles />
      <div className="relative z-10">
        {!isAuthenticated ? (
          <LoginForm onLoginSuccess={handleLoginSuccess} />
        ) : (
          <Dashboard onLogout={handleLogout} />
        )}
      </div>
    </div>
  );
}
